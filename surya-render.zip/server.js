const express = require('express');
const fetch = require('node-fetch');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

const CF_APP_ID = "11181210c86f8a310f9ca1ccbb01218111";
const CF_SECRET_KEY = "cfsk_ma_prod_71abc06e525ce60544e095d2ce4e4fcf_258f4fdd";
const SCRIPT_URL = "https://script.google.com/macros/s/AKfycbx3acvlnqiyROjlQR_mR1e6k1JeWryithW_jCSMapCB9CUWSzNunQ8Ye8b19BcRb6vf/exec";

// Payment API
app.get('/api/payment', async (req, res) => {
  const { amount, mobile, customer, tech, village, vccdsn, service } = req.query;

  if (!amount || !mobile || !customer) {
    return res.json({ error: "Missing required fields" });
  }

  const orderId = "SDH_" + Date.now();

  try {
    const cfRes = await fetch("https://api.cashfree.com/pg/orders", {
      method: "POST",
      headers: {
        "x-api-version": "2023-08-01",
        "x-client-id": CF_APP_ID,
        "x-client-secret": CF_SECRET_KEY,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        order_id: orderId,
        order_amount: parseFloat(amount),
        order_currency: "INR",
        customer_details: {
          customer_id: "CUST_" + mobile,
          customer_name: customer,
          customer_phone: mobile
        },
        order_meta: {
          return_url: "https://surya-dth-payment.onrender.com/payment.html"
        }
      })
    });

    const cfData = await cfRes.json();

    if (!cfData.payment_session_id) {
      return res.json({ error: "Cashfree error: " + JSON.stringify(cfData) });
    }

    // Save to Google Sheet
    const saveUrl = `${SCRIPT_URL}?action=save&amount=${encodeURIComponent(amount)}&tech=${encodeURIComponent(tech||"")}&customer=${encodeURIComponent(customer)}&mobile=${encodeURIComponent(mobile)}&village=${encodeURIComponent(village||"")}&vccdsn=${encodeURIComponent(vccdsn||"")}&service=${encodeURIComponent(service||"")}&order_id=${orderId}`;
    await fetch(saveUrl).catch(() => {});

    res.json({
      payment_session_id: cfData.payment_session_id,
      order_id: orderId
    });

  } catch (error) {
    res.json({ error: error.toString() });
  }
});

// Webhook
app.post('/api/webhook', async (req, res) => {
  try {
    const body = req.body;
    if (body.data && body.data.order) {
      const orderId = body.data.order.order_id;
      const status = body.data.payment && body.data.payment.payment_status === "SUCCESS" ? "SUCCESS" : "FAILED";
      const updateUrl = `${SCRIPT_URL}?action=updatestatus&order_id=${orderId}&status=${status}`;
      await fetch(updateUrl).catch(() => {});
    }
    res.json({ status: "received" });
  } catch (error) {
    res.json({ status: "ok" });
  }
});

// Dashboard data
app.get('/api/data', async (req, res) => {
  try {
    const response = await fetch(`${SCRIPT_URL}?action=getdata`);
    const data = await response.json();
    res.json(data);
  } catch (error) {
    res.json({ error: error.toString() });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
